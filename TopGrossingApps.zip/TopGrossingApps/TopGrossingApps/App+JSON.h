//
//  App+JSON.h
//  TopGrossingApps
//
//  Created by Ahmed Eid on 8/4/12.
//  Copyright (c) 2012 Ahmed Eid. All rights reserved.
//

#import "App.h"

@interface App (JSON)

+ (App *)appFromJSONDictionary:(NSDictionary *)appDictionary intoContext:(NSManagedObjectContext *)context;

@end
