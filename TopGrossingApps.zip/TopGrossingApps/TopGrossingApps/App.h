//
//  App.h
//  TopGrossingApps
//
//  Created by Ahmed Eid on 8/4/12.
//  Copyright (c) 2012 Ahmed Eid. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface App : NSManagedObject

@property (nonatomic, retain) NSString * appCategory;
@property (nonatomic, retain) NSString * appDescription;
@property (nonatomic, retain) NSString * applargeImageURLString;
@property (nonatomic, retain) NSString * appLinkURL;
@property (nonatomic, retain) NSString * appName;
@property (nonatomic, retain) NSString * appReleaseDate;
@property (nonatomic, retain) NSString * appSampleImageURL;
@property (nonatomic, retain) NSString * appsmallImageURLString;
@property (nonatomic, retain) NSNumber * appFavorited;
@property (nonatomic, retain) NSString * appPrice;

@end
