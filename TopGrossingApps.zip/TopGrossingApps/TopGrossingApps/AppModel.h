//
//  AppModel.h
//  TopGrossingApps
//
//  Created by Ahmed Eid on 8/4/12.
//  Copyright (c) 2012 Ahmed Eid. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App+JSON.h"

//Callback and error blocks
typedef void (^CallbackBlock)(NSArray *fetchedAppsArray);
typedef void (^ErrorBlock)(NSError *error);

@interface AppModel : NSObject

//Sngleton class will deal with all core data fetching/saving as well as favoriting apps
+ (AppModel *)sharedInstance;
- (void)saveContext;
- (void)fetchAppsFromiTunesWithCallback:(CallbackBlock)callbackBlock andErrorBlock:(ErrorBlock)errorBlock;

-(NSArray *)favoritedApps;
-(void)addAppToFavorites:(App *)app;

@property (nonatomic, strong) NSManagedObjectContext *context;

@end
