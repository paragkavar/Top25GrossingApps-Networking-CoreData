//
//  App.m
//  TopGrossingApps
//
//  Created by Ahmed Eid on 8/4/12.
//  Copyright (c) 2012 Ahmed Eid. All rights reserved.
//

#import "App.h"


@implementation App

@dynamic appCategory;
@dynamic appDescription;
@dynamic applargeImageURLString;
@dynamic appLinkURL;
@dynamic appName;
@dynamic appReleaseDate;
@dynamic appSampleImageURL;
@dynamic appsmallImageURLString;
@dynamic appFavorited;
@dynamic appPrice;

@end
