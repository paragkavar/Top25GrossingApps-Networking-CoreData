//
//  FavoritesTableViewController.h
//  TopGrossingApps
//
//  Created by Ahmed Eid on 8/4/12.
//  Copyright (c) 2012 Ahmed Eid. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDetailsViewController.h"
#import "AppModel.h"
#import "App.h"

@interface FavoritesTableViewController : UITableViewController

@end
