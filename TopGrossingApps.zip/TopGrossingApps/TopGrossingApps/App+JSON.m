//
//  App+JSON.m
//  TopGrossingApps
//
//  Created by Ahmed Eid on 8/4/12.
//  Copyright (c) 2012 Ahmed Eid. All rights reserved.
//

#import "App+JSON.h"

@implementation App (JSON)

+ (App *)appFromJSONDictionary:(NSDictionary *)appDictionary intoContext:(NSManagedObjectContext *)context;
{
    App *newApp = [NSEntityDescription insertNewObjectForEntityForName:@"App"
                                         inManagedObjectContext:context];
    newApp.appCategory = [[[appDictionary objectForKey:@"category"] objectForKey:@"attributes"] objectForKey:@"label"];
    newApp.appDescription = [[appDictionary objectForKey:@"summary"] objectForKey:@"label"];
    NSArray *linksArray = [appDictionary objectForKey:@"link"];
    newApp.appSampleImageURL = [[[linksArray objectAtIndex:1] objectForKey:@"attributes"] objectForKey:@"href"];
    newApp.appLinkURL = [[[linksArray objectAtIndex:0] objectForKey:@"attributes"] objectForKey:@"href"];
    newApp.applargeImageURLString = [[[appDictionary objectForKey:@"im:image"] objectAtIndex:2] objectForKey:@"label"];
    newApp.appsmallImageURLString = [[[appDictionary objectForKey:@"im:image"] objectAtIndex:1] objectForKey:@"label"];
    newApp.appName = [[appDictionary objectForKey:@"title"] objectForKey:@"label"];
    newApp.appPrice = [[appDictionary objectForKey:@"im:price"] objectForKey:@"label"];    
    newApp.appReleaseDate = [[[appDictionary objectForKey:@"im:releaseDate"] objectForKey:@"attributes"] objectForKey:@"label"];
    
    [newApp setAppFavorited:[NSNumber numberWithBool:NO]];
    return newApp;
    
    [newApp release];
}

@end
