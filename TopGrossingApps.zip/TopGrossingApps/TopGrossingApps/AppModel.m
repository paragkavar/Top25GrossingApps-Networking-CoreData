//
//  AppModel.m
//  TopGrossingApps
//
//  Created by Ahmed Eid on 8/4/12.
//  Copyright (c) 2012 Ahmed Eid. All rights reserved.
//

#import "AppModel.h"
#define kBgQueue dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)
#define kAPIURLString @"http://ax.itunes.apple.com/WebObjects/MZStoreServices.woa/ws/RSS/topgrossingapplications/sf=143441/limit=25/json"

@implementation AppModel
@synthesize context = _context;

+(AppModel *)sharedInstance {
    static AppModel *sharedInstance = nil;
    static dispatch_once_t onceQueue;
    dispatch_once(&onceQueue, ^{
        sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
}

-(AppModel *)init {
    self = [super init];
    return self;
}

- (void)saveContext
{
    NSError *error = nil;
    NSManagedObjectContext *managedObjectContext = self.context;
    if (managedObjectContext != nil) {
        if ([managedObjectContext hasChanges] && ![managedObjectContext save:&error]) {
            NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        }
    }
    [error release];
}

- (void) fetchAppsFromiTunesWithCallback:(CallbackBlock)callbackBlock andErrorBlock:(ErrorBlock)errorBlock
{
    __block NSMutableArray *parsedApps = [[NSMutableArray alloc] init];
    dispatch_async(kBgQueue, ^{
        NSData* data = [NSData dataWithContentsOfURL:[NSURL URLWithString:kAPIURLString]];

        NSError* error;
        NSDictionary* json = [NSJSONSerialization JSONObjectWithData:data //1
                                                             options:kNilOptions
                                                               error:&error];
        
        NSArray* unparsedAppDictionaries = [[json objectForKey:@"feed"] objectForKey:@"entry"];

        for (NSDictionary *appDictionary in unparsedAppDictionaries) {
            App *app = [App appFromJSONDictionary:appDictionary intoContext:self.context];
            [parsedApps addObject:app];
        }
        if (callbackBlock){
            callbackBlock([NSArray arrayWithArray:parsedApps]);
        }
    });
    [self saveContext];
}

-(NSArray *)favoritedApps
{
    NSFetchRequest *favoritesFetch = [NSFetchRequest fetchRequestWithEntityName:@"App"];
    [favoritesFetch setPredicate:[NSPredicate predicateWithFormat:@"appFavorited = 1"]];
    NSError *error = nil;
    NSArray *fetchedFavorites = [self.context executeFetchRequest:favoritesFetch error:&error];
    return fetchedFavorites;
}

-(void)addAppToFavorites:(App *)app
{
    NSFetchRequest *appFetch = [NSFetchRequest fetchRequestWithEntityName:@"App"];
    [appFetch setPredicate:[NSPredicate predicateWithFormat:@"appName like %@", app.appName]];
    NSError *error = nil;
    NSArray *fetchedApps = [self.context executeFetchRequest:appFetch error:&error];
    App *appToBeFavorited = [fetchedApps lastObject];
    [appToBeFavorited setAppFavorited: [NSNumber numberWithBool:YES]];
    [self saveContext];
}

-(void)dealloc
{
    [super dealloc];
    self.context = nil;
}

@end
