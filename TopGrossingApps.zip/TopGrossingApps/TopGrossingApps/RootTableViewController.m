//
//  RootTableViewController.m
//  TopGrossingApps
//
//  Created by Ahmed Eid on 8/4/12.
//  Copyright (c) 2012 Ahmed Eid. All rights reserved.
//

#import "RootTableViewController.h"

@interface RootTableViewController ()
{
    BOOL isLoading;
}
@end

@implementation RootTableViewController
@synthesize appsArray = _appsArray;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        self.title = @"Top 25";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self showTutorial];
    
    isLoading = YES;
    
    [[AppModel sharedInstance] fetchAppsFromiTunesWithCallback:^(NSArray *fetchedApps) {
        //Set our model
        self.appsArray = [NSArray arrayWithArray:fetchedApps];
        isLoading = NO;
        //Reload tableview on the main thread, as UIKit calls need to be made on the main thread 
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.tableView reloadData];
        });
    }andErrorBlock:^(NSError *error){
        //In a real app, would handle error much more gracefully
        NSLog (@"Error found: %@", error);
    }];

}

-(void)showTutorial {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Instructions" message:@"Tap on accessory button to add to favorites. Tap on cell for app details" delegate:nil cancelButtonTitle:@"Got it" otherButtonTitles:nil, nil];
    [alert show];
    [alert release];
}

- (void)viewDidUnload {
    self.appsArray = nil;
}

- (void)dealloc {
    self.appsArray = nil;
    isLoading = NO;
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (isLoading) {
        return 1;
    } else {
        return self.appsArray.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (isLoading) {
        static NSString *loadingCellIdentifier = @"LoadingCell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:loadingCellIdentifier];
        if (cell==nil) {
            cell= [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:loadingCellIdentifier] autorelease];
            cell.accessoryType = UITableViewCellAccessoryNone;
        }
        cell.textLabel.text = @"Loading...";
        return cell;
        
    } else {
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell==nil) {
        cell= [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier] autorelease];
        cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
    }
    App *app = [self.appsArray objectAtIndex:indexPath.row];
    cell.textLabel.text = app.appName;
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ (%@)", app.appCategory, app.appPrice];
    
    return cell;
    }
}


#pragma mark - Table view delegate

-(void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    App *app = [self.appsArray objectAtIndex:indexPath.row];

    if (app.appFavorited.boolValue == NO) {
        [[AppModel sharedInstance] addAppToFavorites:app];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:[NSString stringWithFormat:@"Added %@ to favorites", app.appName] delegate:nil cancelButtonTitle:@"Victory!" otherButtonTitles:nil, nil];
        [alert show];
        [alert release];
    } 

}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (!isLoading) {
        [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    App *app = [self.appsArray objectAtIndex:indexPath.row];
        AppDetailsViewController *controller = [[AppDetailsViewController alloc] initWithApp:app];
        controller.modalPresentationStyle = UIModalPresentationFormSheet;
        
        [self presentViewController:controller animated:YES completion:nil];
        [controller release];
        
    }
}

@end
