//
//  AppDetailsViewController.m
//  TopGrossingApps
//
//  Created by Ahmed Eid on 8/4/12.
//  Copyright (c) 2012 Ahmed Eid. All rights reserved.
//

#import "AppDetailsViewController.h"

@implementation AppDetailsViewController
@synthesize shareActionSheet = _shareActionSheet;
@synthesize app = _app;
@synthesize appIconImageView;
@synthesize appNameLabel;
@synthesize appPriceLabel;
@synthesize appCategoryLabel;
@synthesize appSummaryLabel;
@synthesize appSampleImageView;

-(id)initWithApp:(App *)app
{
    self = [super init];
    if (self) {
        self.app = app;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.appNameLabel.text = self.app.appName;
    self.appIconImageView.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:self.app.applargeImageURLString]]];
    self.appPriceLabel.text = self.app.appPrice;
    self.appCategoryLabel.text = self.app.appCategory;
    self.appSummaryLabel.text = self.app.appDescription;
    
}

- (void)viewDidUnload
{
    [self setAppIconImageView:nil];
    [self setAppNameLabel:nil];
    [self setAppPriceLabel:nil];
    [self setAppCategoryLabel:nil];
    [self setAppSummaryLabel:nil];
    [self setAppSampleImageView:nil];
    [super viewDidUnload];
}

- (void)dealloc {
    [appIconImageView release];
    [appNameLabel release];
    [appPriceLabel release];
    [appCategoryLabel release];
    [appSummaryLabel release];
    [appSampleImageView release];
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return YES;
}


- (IBAction)cancelButtonPressed:(id)sender {
    [self.shareActionSheet dismissWithClickedButtonIndex:0 animated:NO];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)shareButtonPressed:(id)sender {
    self.shareActionSheet = [[[UIActionSheet alloc] initWithTitle:@"Share" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Twitter", @"Email", @"Copy App Description", @"Copy App Link", nil] autorelease];
    [self.shareActionSheet showFromBarButtonItem:sender animated:YES];
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex) {
        case 0:{
            [self sendTweet];
        }
            break;
        case 1:{
            [self sendEmail];
        }
            break;
        case 2:{
            [self copyAppDescription];
        }
            break;
        case 3:{
            [self copyAppLink];
        }
            break;
        default:
            break;
    }
}


-(void)sendTweet {
    TWTweetComposeViewController *controller = [[[TWTweetComposeViewController alloc] init] autorelease];
    [controller addImage:self.appIconImageView.image];
    [controller setInitialText:[NSString stringWithFormat:@"Check out this cool app: %@", self.app.appName]];
    [self presentViewController:controller animated:YES completion:nil];
}

-(void)sendEmail {
    MFMailComposeViewController *controller = [[[MFMailComposeViewController alloc] init] autorelease];
    [controller setMailComposeDelegate:self];
    [controller setMessageBody:[NSString stringWithFormat:@"Check out this awesome app! %@", self.app.appName] isHTML:NO];
    [controller setToRecipients:[NSArray arrayWithObject:@"AhmedEid@Me.Com"]];
    
    UIImage *appImage = self.appIconImageView.image;
    NSData *myImageData = UIImagePNGRepresentation(appImage);
    [controller addAttachmentData:myImageData mimeType:@"image/png" fileName:@"appImage.png"];

    [self presentViewController:controller animated:YES completion:nil];
}

-(void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)copyAppDescription {
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = [NSString stringWithFormat:@"%@ Description: %@", self.app.appName, self.app.appDescription];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Copied Text Successfully" message:@"Booya!" delegate:nil  cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
    [alert show];
    [alert release];
}

-(void)copyAppLink {
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = self.app.appLinkURL;
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Copied Text Successfully" message:@"Booya!" delegate:nil  cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
    [alert show];
    [alert release];
}

@end
