//
//  AppDetailsViewController.h
//  TopGrossingApps
//
//  Created by Ahmed Eid on 8/4/12.
//  Copyright (c) 2012 Ahmed Eid. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "App.h"

@interface AppDetailsViewController : UIViewController <UIActionSheetDelegate, MFMailComposeViewControllerDelegate>

@property (nonatomic, retain) App *app;

-(id)initWithApp:(App *)app;

@property (retain, nonatomic) IBOutlet UIImageView *appIconImageView;
@property (retain, nonatomic) IBOutlet UILabel *appNameLabel;
@property (retain, nonatomic) IBOutlet UILabel *appPriceLabel;
@property (retain, nonatomic) IBOutlet UILabel *appCategoryLabel;
@property (retain, nonatomic) IBOutlet UILabel *appSummaryLabel;
@property (retain, nonatomic) IBOutlet UIImageView *appSampleImageView;
@property (retain, nonatomic) UIActionSheet *shareActionSheet;

- (IBAction)cancelButtonPressed:(id)sender;
- (IBAction)shareButtonPressed:(id)sender;

@end
